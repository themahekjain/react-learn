export const Home =() =>{
    return(
        <h1>Welcome To Home</h1>
    )
}